import java.io.IOException;
public class StudentResultSystem {
    public static void main(String[] args)
        throws IOException
   {  
      StudentResult menu = new StudentResult();
      menu.run();
   }
}